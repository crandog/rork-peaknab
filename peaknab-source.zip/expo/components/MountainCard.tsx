import React, { memo, useRef } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Animated } from 'react-native';

import Colors from '@/constants/colors';
import { Mountain } from '@/constants/mountains';
import MountainIcon from '@/components/MountainIcon';

interface MountainCardProps {
  mountain: Mountain;
  isSummited: boolean;
  summitDate?: string;
  summitCount?: number;
  onPress: () => void;
  useFeet?: boolean;
}

function MountainCardComponent({ mountain, isSummited, summitDate, summitCount = 0, onPress, useFeet = false }: MountainCardProps) {
  const scaleAnim = useRef(new Animated.Value(1)).current;

  const handlePressIn = () => {
    Animated.spring(scaleAnim, {
      toValue: 0.97,
      useNativeDriver: true,
    }).start();
  };

  const handlePressOut = () => {
    Animated.spring(scaleAnim, {
      toValue: 1,
      friction: 3,
      useNativeDriver: true,
    }).start();
  };

  return (
    <Animated.View style={[styles.cardWrapper, { transform: [{ scale: scaleAnim }] }]}>
      <TouchableOpacity
        style={[
          styles.card,
          isSummited && styles.cardSummited,
        ]}
        onPress={onPress}
        onPressIn={handlePressIn}
        onPressOut={handlePressOut}
        activeOpacity={0.9}
        testID={`mountain-card-${mountain.id}`}
      >
        <View style={styles.cardContent}>
          <View style={styles.leftSection}>
            <MountainIcon mountainId={mountain.id} category={mountain.category} size={76} />
          </View>

          <View style={styles.centerSection}>
            <Text style={styles.name} numberOfLines={1}>{mountain.name}</Text>
            <Text style={styles.locationText} numberOfLines={1}>
              {mountain.country} · {mountain.range}
            </Text>
          </View>

          {isSummited && (
            <View style={styles.summitCenter}>
              <View style={styles.summitBadgeRow}>
                <View style={styles.summitBadge}>
                  <Text style={styles.summitBadgeText}>SUMMITED</Text>
                </View>
                {summitCount > 1 && (
                  <View style={styles.summitCountBadge}>
                    <Text style={styles.summitCountText}>x{summitCount}</Text>
                  </View>
                )}
              </View>
              {summitDate && (
                <View style={styles.dateBox}>
                  <Text style={styles.dateText}>{formatSummitDate(summitDate)}</Text>
                </View>
              )}
            </View>
          )}

          <View style={styles.rightSection}>
            <Text style={[styles.elevation, isSummited && styles.elevationSummited]}>
              {useFeet
                ? `${mountain.elevationFt.toLocaleString()}ft`
                : `${mountain.elevation.toLocaleString()}m`}
            </Text>
          </View>
        </View>
      </TouchableOpacity>
    </Animated.View>
  );
}

function formatSummitDate(dateStr: string): string {
  const MONTHS: Record<string, string> = {
    'January': 'JAN', 'February': 'FEB', 'March': 'MAR', 'April': 'APR',
    'May': 'MAY', 'June': 'JUN', 'July': 'JUL', 'August': 'AUG',
    'September': 'SEP', 'October': 'OCT', 'November': 'NOV', 'December': 'DEC',
  };
  const parts = dateStr.match(/^(\w+)\s+(\d+),\s+(\d+)$/);
  if (parts) {
    const monthAbbr = MONTHS[parts[1]] ?? parts[1].slice(0, 3).toUpperCase();
    return `${monthAbbr} ${parts[2]}, ${parts[3]}`;
  }
  return dateStr;
}

export default memo(MountainCardComponent);

const styles = StyleSheet.create({
  cardWrapper: {
    marginBottom: 0,
  },
  card: {
    backgroundColor: 'transparent',
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: Colors.border + '50',
  },
  cardSummited: {
    backgroundColor: 'rgba(192, 57, 43, 0.03)',
  },
  cardContent: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 0,
    paddingRight: 18,
    paddingLeft: 0,
    minHeight: 76,
  },
  leftSection: {
    marginRight: 14,
    width: 76,
    height: 76,
    alignItems: 'center',
    justifyContent: 'center',
  },
  centerSection: {
    flex: 1,
    marginRight: 8,
  },
  name: {
    fontSize: 15,
    fontWeight: '600' as const,
    color: Colors.text,
    flexShrink: 1,
  },
  summitCenter: {
    alignItems: 'center',
    marginRight: 12,
  },
  summitBadgeRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  summitBadge: {
    borderWidth: 2,
    borderColor: '#C0392B',
    borderRadius: 3,
    paddingHorizontal: 6,
    paddingVertical: 2,
    transform: [{ rotate: '-4deg' }],
  },
  summitBadgeText: {
    fontSize: 8,
    fontWeight: '900' as const,
    color: '#C0392B',
    letterSpacing: 1.5,
  },
  summitCountBadge: {
    backgroundColor: '#C0392B',
    borderRadius: 8,
    paddingHorizontal: 5,
    paddingVertical: 1,
    minWidth: 22,
    alignItems: 'center',
  },
  summitCountText: {
    fontSize: 9,
    fontWeight: '800' as const,
    color: '#FFFFFF',
    letterSpacing: 0.3,
  },
  dateBox: {
    backgroundColor: '#2E86C1',
    borderRadius: 3,
    paddingHorizontal: 6,
    paddingVertical: 2,
    marginTop: 4,
  },
  dateText: {
    fontSize: 7,
    fontWeight: '700' as const,
    color: '#FFFFFF',
    letterSpacing: 0.5,
  },
  locationText: {
    fontSize: 12,
    color: Colors.textMuted,
    marginTop: 2,
  },
  rightSection: {
    alignItems: 'flex-end',
  },
  elevation: {
    fontSize: 13,
    fontWeight: '500' as const,
    color: Colors.textSecondary,
  },
  elevationSummited: {
    color: Colors.text,
  },
  elevationAlt: {
    fontSize: 11,
    color: Colors.textMuted,
    marginTop: 1,
  },
});
